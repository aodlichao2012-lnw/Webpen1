    <footer style="background: rgb(23, 37, 42); padding: 40px 0px; color: white;">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <h4><?= _contact ?></h4>
                    <p>
                        <?= _pennueng ?><br><br>

                        <?= _add ?> <br>
                        <?= _add2 ?><br>
                        <?= _add3 ?><br>
                        0936545544.<br><br>
                        Email<br>
                        <?= _sale ?><br>
                        <?= _service ?><br><br>
                        <?= _map2 ?> : <a href="https://www.google.com/maps/place/%E0%B9%80%E0%B8%9B%E0%B9%87%E0%B8%99%E0%B8%AB%E0%B8%99%E0%B8%B6%E0%B9%88%E0%B8%87+%E0%B9%82%E0%B8%AE%E0%B8%A5%E0%B8%94%E0%B8%B4%E0%B9%89%E0%B8%87/@13.773374,100.615741,17z/data=!4m5!3m4!1s0x0:0x5277dd21da97f149!8m2!3d13.7733743!4d100.6157405?hl=th"><?= _click ?></a>
                        
                </div>
                <!-- <div class="col-lg-4 col-md-6 col-sm-12">
                    <h4>SOCIAL</h4>
                    <div class="row">
                        <div>
                            <ul class="social-network social-circle">
                                <li><a href="https://www.facebook.com/pen1.biz/" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="https://line.me/ti/p/rVmlamr6ke" class="icoRss" title="line"><i class="fa fa-qrcode"></i></a></li>
                                <li><a href="Mailto:sales@pen1.biz" class="icoGoogle" title="Mail"><i class="fa fa-envelope"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div> -->
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <h4><?= _map ?></h4>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1937.5455779072292!2d100.61496668356745!3d13.773376140863634!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30e2992e92321475%3A0x5277dd21da97f149!2z4LmA4Lib4LmH4LiZ4Lir4LiZ4Li24LmI4LiHIOC5guC4ruC4peC4lOC4tOC5ieC4hw!5e0!3m2!1sth!2sth!4v1623053638446!5m2!1sth!2sth" width="100%" height="100%" style="border:0; border-radius: 5px;" allowfullscreen="" loading="lazy"></iframe>
                </div>
                <em>Copyright © 2021 Pennueng Holding Co., Ltd, All Rights Reserved.</em>
            </div>
        </div>
    </footer>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    </body>

    </html>