<?php

// Page Home 

define("_Home", "Home");
define("_About_Us", "About");
define("_Product", "Product");
define("_Service", "Service");
define("_Promotion", "Promotion");
define("_recommend", "Offer");
define("_recommend_product", "Presentation");
define("_News", "News");
define("_Order", "Order");
define("_Job", "Apply");
define("_Support", "Support");
define("_Language", "EN");

define("_Intelligent_library", "Intelligent library system");
define("_Smart_door", "Smart door");
define("_Smart_circuit_board", "Smart circuit board radio waves");
define("_Automatic_library", "Automatic library resource borrowing machine");
define("_Loan_service_kit", "A collection of borrowing/returning resources through a librarian.");
define("_Support_mobile_storage_kits", "Support mobile storage kits");
define("_Automatic_library_material_return_device", "Automatic library material return device");
define("_Circuit_board_data_coding_kit", "Circuit board data coding kit");
define("_Intelligent_Library_System_Control_Unit", "Intelligent Library System Control Unit");
define("_Library_membership_card", "Library membership card with radio wave technology");
define("_Training_and_maintenance", "Training and maintenance");
define("_Other_details", "Other details");

define("_usage_leader", "The Leader of RFID system");
define("_system_rfid", "");
define("_home1", "We are the leader in design, development and provide the global services");
define("_home2", "with the quality product and the heartfelt service.");
define("_home3", "");

define("_why", "Why Pennueng ?");
define("_why1", "Above 20 years experienced");
define("_why2", "Provided the global resource");
define("_why3", "management that customers trust.");

define("_why4", "Imported the modern foreign product.");
define("_why5", "");
define("_why6", "we use the equipment and products of the global standardization for the most efficiency.");
define("_why7", "");

define("_why8", "Feedback from many trusted customers.");
define("_why9", "");
define("_why10", "We have provided the excellent services and installed the effective system for the top universities across the country such as Thammasat University (all campuses), King Mongkut's Institute of Technology Ladkrabang and else. ");
define("_why11", "");
define("_why12", "");
define("_why13", "");
define("_why14", "");

define("_why15", "Easy to use system");
define("_why16", "We are always determined to develop the effective system for our customers to use a simple and the most effective system.");
define("_why17", "");
define("_why18", "");

define("_why19", "The Intelligent Library Network Specialist");
define("_why20", "");
define("_why21", "Develop the various electronic solutions such as e-payment, e-library and else.");
define("_why22", "");

define("_why23", "The Professional team");
define("_why24", "Above 20 years experienced, we are ready and willing to provide the best customer service.");

define("_product2", "All Products");

define("_product_name1", "The Intelligent Library Management System");
define("_product_name2", "The Intelligent RFID Pathway");
define("_product_name3", "Electronics Magnetic System");
define("_product_name4", "Self-Checkout Kiosk");
define("_product_name5", "Book Return");
define("_product_name6", "Access Control System");
define("_product_name7", "RFID Inventory System");
define("_product_name8", "The Intelligent Librarian System");
define("_product_name9", "RFID Tags");
define("_product_name10", "Mifare Card");
define("_product_name11", "Book Scanner");
define("_product_name12", "Smart Locker");
define("_product_name13", "Self Service Kiosk");
define("_product_name14", "Smart Robot");

define("_sample", "Examples of RFID intelligent library system installation work");

define("_user", "Customer's feedback");

define("_user1", "Be professional, work and measure");
define("_user2", "A good working base to give advice");
define("_user3", "and good and friendly advice.");
define("_user3_2", "Ramkhamhaeng University");

define("_user4", "The team is ready and capable");
define("_user5", "can be corrected immediately");
define("_user6", "to keep the work going.");
define("_user6_2", "King Mongkut's Institute of Technology Ladkrabang");

define("_user7", "The company has new products");
define("_user8", "can be recommended for use");
define("_user9", "for ease of work.");
define("_user9_2", "Mahasarakham University");

define("_our_Services", "Pennueng Services");
define("_our_Services1", "The high standard of product warranty and after-sale services of Pennueng.");

define("_partner", "Partner");

define("_contact", "CONTACT US");
define("_sale", "Sales : sales@pen1.biz");
define("_service", "Service : customerservice@pen1.biz");
define("_map", "GOOGLE MAP");
define("_map2", "Google Map");
define("_click", "Click here");

define("_add", "Head Office 576/18");
define("_add2", "Soi Ladprao 112 (Iam Somboon)");
define("_add3", "Phlapphla Subdistrict, Wang Thonglang District, Bangkok 10310");

define("_pennueng", "Pennueng Holding Company Limited");
define("_Buy", "Buy");
define("_View", "Detail");
define("_Views", "views");

//Page About

define("_About", "About us");
define("_About1", "Pennueng Holding Co.,Ltd. is a leader in the development of the Resource Management System by emphasizing on the modern technology and global standardization; developing the system based on the real experience above 20 years. We are willing to provide a professional advice and help in solving any industries process problems by our professional team and sincerely service.");
define("_About2", "");
define("_About3", "");

define("_vision", "Vision");
define("_vision1", "The leader in design, development and provide the global services that the customers trust with the quality product and the heartfelt service.");
define("_vision2", "");
define("_vision3", "");

define("_mission", "Mission");
define("_mission1", "Operate one-stop service of the Resource Management business to be a leader of sustainable business.");
define("_mission2", "");
define("_mission3", "");
define("_mission4", "");
define("_mission5", "");
define("_mission6", "");
define("_mission7", "");
define("_mission8", "");
define("_mission9", "");
define("_mission10", "");

define("_goals", "Objective");
define("_goals1", "Operate one-stop service of the Resource Management business to be a leader of sustainable business. ");
define("_goals2", "Support the linkage between libraries that use the RFID system for cooperation in sharing ");
define("_goals3", "resources (Inter-Library Loan) increased 10% of libraries in Thailand.");
define("_goals4", "Increasing 10% of library that use RFID system in Thailand.");
define("_goals5", "Provide an excellent service of RFID system in foreign libraries.");
define("_goals6", "");
define("_goals7", "");
define("_goals8", "");
define("_goals9", "");

define("_product_type", "Product Type");

define("_product_type1", "The Intelligent Library Management System");
define("_product_type2", "The Intelligent RFID Pathway");
define("_product_type3", "Electronics Magnetic System");
define("_product_type4", "Self-Checkout Kiosk");
define("_product_type5", "Book Return");
define("_product_type6", "Access Control System");
define("_product_type7", "RFID Inventory System");
define("_product_type8", "The Intelligent Librarian System");
define("_product_type9", "RFID Tags");
define("_product_type10", "Mifare Card");
define("_product_type11", "Book Scanner");
define("_product_type12", "Smart Locker");
define("_product_type13", "Self Service Kiosk");
define("_product_type14", "Smart Robot");

define("_headoffice", "Head office");
define("_headoffice1", "576/18 Ladprao Road 112");
define("_chiangmai", "Chiang Mai Branch");
define("_chiangmai1", "298/12 Ornsirin Village 14 Moo 5, Pa Phai Subdistrict, San Sai District, Chiang Mai Province 50210");
define("_phone", "Phone");
define("_phone1", "02 150 6700 , 093 654 5544");
define("_fanpage", "Fanpage");

// Product

define("_productpage", "Take a step with us with state-of-the-art equipment.");

// Service

define("_servicepage", "We are always happy and ready to serve you.");
define("_pre_sale", "Before Sale Service");
define("_pre_sale1", "A service of product details consultant and system installation");
define("_pre_sale2", "You can contact us to discuss either choosing the right products or services for your organization or installing a new system to increase your productivity; whether product details inquiry or the installation of the Intelligent RFID Library System, Inventory Management System and Smart Locker demonstrations, it can reduce workflow and save time. In addition, your sales and purchases will be more convenient and faster; especially, the payment solutions, issuing the receipt, the Inventory write-off and using the correct equipment’s for optimal performance.");
define("_pre_sale3", "");
define("_pre_sale4", "");
define("_pre_sale5", "");
define("_pre_sale51", "");
define("_pre_sale6", "Product demonstration service");
define("_pre_sale7", "We are ready to demonstrate products such as smart lockers. RFID stock monitors and more to present workflows to help you make faster decisions.");
define("_pre_sale8", "");

define("_after_sale", "After-Sale Service");
define("_after_sale1", "The form of our service");
define("_after_sale2", "We provide product inspection and cleaning services by serving you with hospitality and care.");
define("_after_sale3", "Maintenance Agreement (MA)");
define("_after_sale4", "Maintenance of the systems or products after the warranty period has expired and customers wish a continuous service. You can renew the MA on an annual basis starting after the contract has been agreed.");
define("_after_sale5", "");
define("_after_sale6", "Service Details:");
define("_after_sale7", "MA is a type of maintenance service which includes the cost of spare parts, labor costs, travel expenses, etc., as well as the inspection of work procedures and cleaning of the products as stipulated in the contract.");
define("_after_sale8", "");
define("_after_sale9", "On-Call :");
define("_after_sale10", "Types of maintenance services in the event that the customer does not enter into a maintenance contract. You can choose this service after the warranty has been expired.");
define("_after_sale11", "Service details");
define("_after_sale12", "On-call service will charge the costs of services, spare parts, travel expenses, etc. with no monthly maintenance visits and no spare machines in case they can't be repaired.");
define("_after_sale13", "");
define("_after_sale14", "The form of our service");
define("_after_sale15", "On-Site :");
define("_after_sale16", "is the service that we provide the on-site service by our professional technicians for product repair.");
define("_after_sale17", "In Warranty :");
define("_after_sale18", "This is a service that checks, repairs and replaces parts for products or systems that are still under warranty at no additional cost.");
define("_after_sale19", "Out Warranty :");
define("_after_sale20", "In case of your products or systems is end of warranty period, we will check your products or systems including quote the costs of repair, spare parts and also service costs for you so that you can consider the details first. The company reserves the right to repair your product or system only after your approval.");
define("_after_sale21", "");
define("_after_sale22", "");

define("_delivery_service", "Delivery service");
define("_delivery_service1", "We have delivery service to your hand.");
define("_delivery_service2", "1. Ship the goods by our couriers. (Only in Bangkok and surrounding areas) as soon as you receive the product Please check the correctness of the product as specified in the consignment note.");
define("_delivery_service3", "2. Send products by postal parcel. It will be delivered as a postal parcel. to the address of the consignee The delivery time is approximately 1-2 days for Bangkok and surrounding areas after the delivery date and 5-7 days for other provinces after the delivery date.");
define("_delivery_service4", "You can ask for details. service area and how to deliver from the staff again");

define("_product_pickup", "Product pickup");
define("_product_pickup1", "in product inspection when the product is delivered to you Please check the product immediately. for your own benefit If an error occurs");
define("_product_pickup2", "Please report back to the company. Immediately within the date of receiving the product, the company reserves the right to not be responsible in any case If not notified of the delivery error.");
define("_product_pickup3", "");

// Promotion

define("_promotion", "New promotions coming soon");
define("_promotion1", "or contact 02-150-6700");
define("_promotion2", "Promotion channel");
define("_promotion3", "You can follow new promotions at");
define("_promotion4", "fanpage");
define("_promotion5", "of the way is one holding to stay up to date with new news and promotions that will be available soon.");
define("_promotion6", "Phone.");

// News

define("_news", "News");
define("_news1", "See more");

// Order

define("_order", "Place an order");
define("_orderForm1", "Product list :");
define("_orderForm2", "*- select product");
define("_orderForm3", "Quantity :");
define("_orderForm4", "*- select number");
define("_orderForm5", "Fristname :");
define("_orderForm6", "Fristname");
define("_orderForm7", "Lastname :");
define("_orderForm8", "Lastname");
define("_orderForm9", "Email :");
define("_orderForm10", "Email");
define("_orderForm11", "Phone :");
define("_orderForm12", "Phone");
define("_orderForm13", "Phone (Reserve) :");
define("_orderForm14", "Phone");
define("_orderForm15", "Number :");
define("_orderForm16", "Number");
define("_orderForm17", "Group :");
define("_orderForm18", "Group");
define("_orderForm19", "Soi :");
define("_orderForm20", "Soi");
define("_orderForm21", "Village/Building :");
define("_orderForm22", "Village/Building");
define("_orderForm23", "Road :");
define("_orderForm24", "Road");
define("_orderForm25", "Sub-district :");
define("_orderForm26", "Sub-district");
define("_orderForm27", "District :");
define("_orderForm28", "District");
define("_orderForm29", "Province :");
define("_orderForm30", "Province");
define("_orderForm31", "ZIP code :");
define("_orderForm32", "ZIP code");
define("_orderForm33", "Send");

// Work

define("_work", "Come and be a part of us...");
define("_work1", "very urgent !");
define("_work2", "Qualifications :");
define("_work3", "apply");

// Support

define("_support", "Notify/inquire about product problems");
define("_support1", "E-mail");
define("_support2", "Fristname - Lastname");
define("_support3", "Company");
define("_support4", "Phone");
define("_support5", "Subject");
define("_support5_1", "General Inquiry");
define("_support5_2", "Request a demonstration");
define("_support5_3", "Request a quote");
define("_support6", "Detail");

//Video

define("_video", "Product introduction");

//Once

define("_once", "On call");
define("_once1", "One-time service");
define("_once2", "Is to provide services in the event that the customer does not enter into a maintenance contract which can choose to use the service after the warranty period has expired");
define("_once3", "Service details");
define("_once4", "one-time service There will be a service charge, spare parts, travel expenses without monthly maintenance. And there is no backup device in case it can't be repaired.");
define("_once5", "Service model");
define("_once6", "On-Site :");
define("_once7", "It is a dispatch of a team of skilled technicians to provide product repair services at the installation site for onsite service.");

define("_once8", "Contact for service at :");
define("_once9", "Pennueng Holding Company Limited");
define("_once10", "Head Office No. 576/18");
define("_once11", "Soi Ladprao 112 (Iam Somboon)");
define("_once12", "Phlapphla Subdistrict, Wang Thonglang District, Bangkok 10310");
define("_once13", "Phone. 02-150-6700");
define("_once14", "Monday - Friday (except public holidays)");
define("_once15", "08.00 - 17.00.");

//MA

define("_ma", "(Maintenance Service Agreement-MA)");
define("_ma1", "Maintenance of a system or product after the warranty period has expired and the customer requires ongoing service. Service insurance can be renewed annually starting after the contract has been agreed.");
define("_ma2", "Service details");
define("_ma3", "It is a form of maintenance contract. that includes spare parts, labor, travel expenses, including taking care of check work Clean the product as specified in the contract.");

//Waranty

define("_wanranty", "(In Warranty)");
define("_wanranty1", "is a check service Repair and replace parts for products or systems that are within the warranty period. free of charge");

//Out Waranty

define("_out_wanranty", "(Out Warranty)");
define("_out_wanranty1", "In the event that your product or system has expired, the company will inspect your product or system. with a price quote for repair Spare parts and service costs to you for you to consider before proceeding The company reserves the right to repair your product or system only after your approval.");
define("_out_wanranty2", "Service fee for inspection and repair");
define("_out_wanranty3", "The company charges spare parts and service fees according to the type. Product model and size You can check the cost of spare parts and the initial service fee at the service staff.");
define("_out_wanranty4", "In the event that you want to use the On Site service, the company will quote an additional fee for you. when approved We will make an appointment to send a team of skilled technicians. Going to the product repair service at the installation site");
