<div class="col-lg-12 bg-light" style="min-height: 5.4rem;"></div>
<div class="col-lg-12 bg-light imgheadcontent" style="height: 15rem;">
    <h6 class="centertext"><?= _once ?></h6>
</div>
<div class="col-lg-12">
    <div class="container">
        <div class="col-lg-12 boxp">
            <div class="col-lg-10 offset-lg-1">
                <h4 style="color:#ee0000;"><?= _once1 ?></h4><br>
                <p>
                    <?= _once2 ?>
                </p><br>
            </div>
            <hr>
            <br>
            <div class="col-lg-10 offset-lg-1">
                <h4 style="color:#ee0000;"><?= _once3 ?></h4><br>
                <!-- <h5>1. การบริการแบบ Carry In :</h5> -->
                <p><?= _once4 ?></p>
                <h4 style="color:#ee0000;"><?= _once5 ?></h4><br>
                <p><?= _once6 ?></p>
                <p><?= _once7 ?></p>
            </div>
            <hr>
            <br>
            <div class="col-lg-10 offset-lg-1">
                <h5><?= _once8 ?></h5>
                <p>
                    <?= _once9 ?><br>
                    <?= _once10 ?><br>
                    <?= _once11 ?><br>
                    <?= _once12 ?><br>
                    <?= _once13 ?><br>
                    <?= _once14 ?><br>
                    <?= _once15 ?><br>
                </p>
            </div>
        </div>
    </div>
</div>
</div>