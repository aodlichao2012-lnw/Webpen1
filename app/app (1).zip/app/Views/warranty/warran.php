<div class="col-lg-12 bg-light" style="min-height: 5.4rem;"></div>
<div class="col-lg-12 bg-light imgheadcontent" style="height: 15rem;">
    <h6 class="centertext"><?= _wanranty ?></h6>
</div>
<div class="col-lg-12">
    <div class="container">
        <div class="col-lg-12 boxp">
            <div class="col-lg-10 offset-lg-1">
                <h4 style="color:#ee0000;"><?= _wanranty ?></h4><br>
                <p>
                    <?= _wanranty1 ?>
                </p><br>
            </div>
            <hr>
            <br>
            <div class="col-lg-10 offset-lg-1">
                <h5><?= _once8 ?></h5>
                <p>
                    <?= _once9 ?><br>
                    <?= _once10 ?><br>
                    <?= _once11 ?><br>
                    <?= _once12 ?><br>
                    <?= _once13 ?><br>
                    <?= _once14 ?><br>
                    <?= _once15 ?><br>
                </p>
            </div>
        </div>
    </div>
</div>
</div>