<div class="col-lg-12 bg-light" style="min-height: 5.4rem;"></div>
<div class="col-lg-12 bg-light imgheadcontent" style="height: 15rem;">
    <h1 class="centertext"><?= _servicepage ?> ...</h1>
</div>
<div class="col-lg-12">
    <div class="container">
        <div class="col-lg-12 boxp">
            <div class="col-lg-10 offset-lg-1">
                <h2 style="color:#EE0000;"><?= _pre_sale ?></h2><br>
                <h5><?= _pre_sale1 ?></h5>
                <p>
                    <?= _pre_sale2 ?><br>
                    <?= _pre_sale3 ?><br>
                    <?= _pre_sale4 ?><br>
                    <?= _pre_sale5 ?><br>
                    <?= _pre_sale51 ?><br><br>
                <h5><?= _pre_sale6 ?></h5>
                <?= _pre_sale7 ?><br>
                <?= _pre_sale8 ?>
                </p><br>
            </div>
            <hr>
            <br>
            <div class="col-lg-10 offset-lg-1">
                <h2 style="color:#EE0000;"><?= _after_sale ?></h2><br>
                <h5><?= _after_sale1 ?></h5>
                <p><?= _after_sale2 ?></p><br>
                <h5><?= _after_sale3 ?></h5>
                <p>
                    <?= _after_sale4 ?><br>
                    <?= _after_sale5 ?>
                </p><br>
                <h5><?= _after_sale6 ?></h5>
                <p>
                    <?= _after_sale7 ?><br>
                    <?= _after_sale8 ?>
                </p><br>
                <h5><?= _after_sale9 ?></h5>
                <p>
                    <?= _after_sale10 ?>
                </p><br>
                <h5><?= _after_sale11 ?></h5>
                <p>
                    <?= _after_sale12 ?><br>
                    <?= _after_sale13 ?>
                </p><br>
                <h5><?= _after_sale14 ?></h5>
                <h5><?= _after_sale15 ?></h5>
                <p>
                    <?= _after_sale16 ?>
                </p><br>
                <h5><?= _after_sale17 ?></h5>
                <p>
                    <?= _after_sale18 ?>
                </p><br>
                <h5><?= _after_sale19 ?></h5>
                <p>
                    <?= _after_sale20 ?><br>
                    <?= _after_sale21 ?><br>
                    <?= _after_sale22 ?>
                </p><br>
            </div>
            <!-- <hr>
            <br>
            <div class="col-lg-10 offset-lg-1">
                <h2 style="color: #EE0000;"><?= _delivery_service ?></h2><br>
                <h5><?= _delivery_service1 ?></h5>
                <p>
                    <?= _delivery_service2 ?><br><br>
                    <?= _delivery_service3 ?><br>
                </p>
                <p style="color:#EE0000;"><?= _delivery_service4 ?></p><br>
                <h5><?= _product_pickup ?></h5>
                <p>
                    <?= _product_pickup1 ?><br>
                    <?= _product_pickup2 ?><br>
                    <?= _product_pickup3 ?>
                </p>
            </div> -->
        </div>
    </div>
</div>