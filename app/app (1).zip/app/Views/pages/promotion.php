<div class="col-lg-12 bg-light" style="min-height: 5.4rem;"></div>
<div class="col-lg-12 bg-light imgheadcontent" style="height: 15rem;">
    <h1 class="centertext"><?= _promotion ?><br>
        <?= _promotion1 ?></h1>
</div>
<div class="col-lg-12">
    <div class="container">

        <!-- <audio controls>
            <source src="<?php echo base_url('uploads/mp3/imagine_dragon.mp3'); ?>" type="audio/mpeg">
        </audio>

        
        <video width="320" height="240" controls>
            <source src="movie.mp4" type="video/mp4">
            <source src="movie.ogg" type="video/ogg">
        </video> -->
       

        <div class="col-lg-12 boxp">
            <table width=100%>
                <tr>
                    <td style="text-align: center; vertical-align: middle;">
                        <img src="<?php echo base_url('uploads/pic/promotion.jpg'); ?>" alt="promotion" style="width: 80%;">
                    </td>
                </tr>
            </table>
            <br>
            <div class="col-lg-10 offset-lg-1">
                <h2 style="color:#EE0000;"><?= _promotion2 ?></h2><br>
                <h5><?= _promotion3 ?></h5>
                <p>
                    <?= _promotion4 ?> <a href="https://www.facebook.com/pen1.biz/" target="_blank">facebook</a> <?= _promotion5 ?>
                <p>
                <h5><?= _promotion6 ?></h5>
                02 150 6700, 093 654 5544<br>
                02-216-8144
                </p><br>
            </div>
        </div>
    </div>
</div>